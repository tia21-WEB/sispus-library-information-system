<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Perpustakaan</title>
    
    <style>
        body {
            font-family: DejaVu Sans, Arial, sans-serif;
            font-size: 11px;
            color: #333;
            line-height: 1.5;
            margin: 15px;
        }

        /* =====================
           KOP SURAT
        ===================== */
        .kop {
            width: 100%;
            border-bottom: 3px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .kop-table {
            width: 100%;
            border: none;
        }
        .kop-table td {
            border: none;
            vertical-align: middle;
        }
        .logo-kiri, .logo-kanan {
            width: 15%;
            text-align: center;
        }
        .logo-kiri img, .logo-kanan img {
            width: 75px;
        }
        .identitas {
            text-align: center;
            width: 70%;
        }
        .identitas h4 { margin: 2px 0; font-size: 13px; font-weight: bold; }
        .identitas h2 { margin: 2px 0; font-size: 18px; font-weight: bold; }
        .identitas h3 { margin: 2px 0; font-size: 14px; font-weight: bold; color: #2563eb; }
        .identitas p { margin-top: 5px; font-size: 10px; color: #555; }

        /* =====================
           JUDUL LAPORAN
        ===================== */
        .title {
            text-align: center;
            margin: 15px 0 25px 0;
        }
        .title h1 {
            margin: 0;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .title p {
            margin-top: 5px;
            font-size: 11px;
        }
        .badge-periode {
            background-color: #dbeafe;
            color: #1e40af;
            padding: 4px 10px;
            border-radius: 4px;
            font-weight: bold;
            border: 1px solid #bfdbfe;
        }

        /* =====================
           SECTION & TEXT
        ===================== */
        .section-title {
            font-size: 12px;
            font-weight: bold;
            color: #2563eb;
            border-bottom: 1px solid #ccc;
            padding-bottom: 4px;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .note {
            text-align: justify;
            font-size: 10.5px;
            color: #444;
            margin-bottom: 15px;
        }

        /* =====================
           TABEL
        ===================== */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        table th {
            background-color: #f3f4f6;
            font-weight: bold;
            text-align: left;
            padding: 6px 8px;
            font-size: 10px;
            border: 1px solid #d1d5db;
        }
        table td {
            border: 1px solid #d1d5db;
            padding: 6px 8px;
            font-size: 10px;
            vertical-align: middle;
        }
        .text-center { text-align: center !important; }
        .text-right { text-align: right !important; }
        .fw-bold { font-weight: bold; }
        
        /* Pewarnaan Teks & Background */
        .text-primary { color: #2563eb; }
        .text-success { color: #10b981; }
        .text-danger { color: #ef4444; }
        .text-warning { color: #f59e0b; }
        .bg-danger-subtle { background-color: #fee2e2; }
        .bg-warning-subtle { background-color: #fef3c7; }
        
        /* Badges */
        .badge {
            padding: 2px 6px;
            font-size: 9px;
            border-radius: 3px;
            display: inline-block;
            border: 1px solid #ccc;
            background-color: #f9fafb;
            color: #374151;
        }
        .badge-danger { background-color: #fee2e2; color: #991b1b; border-color: #fecaca; }
        .badge-success { background-color: #d1fae5; color: #065f46; border-color: #a7f3d0; }
        .badge-warning { background-color: #fef3c7; color: #92400e; border-color: #fde68a; }
        .badge-primary { background-color: #dbeafe; color: #1e40af; border-color: #bfdbfe; }

        /* =====================
           TANDA TANGAN
        ===================== */
        .footer {
            margin-top: 40px;
            width: 100%;
            page-break-inside: avoid;
        }
        .signature-table {
            width: 100%;
            border: none;
        }
        .signature-table td {
            border: none;
            text-align: center;
            vertical-align: top;
            padding: 0;
            width: 50%;
        }
        .signature-name {
            font-weight: bold;
            text-decoration: underline;
        }
    </style>
</head>
<body>


<!-- KOP SURAT -->
<div class="kop">
    <table class="kop-table">
        <tr>
            <td class="logo-kiri">
                <?php if(file_exists(public_path('img/logo-tutwuri.png'))): ?>
                    <img src="<?php echo e(public_path('img/logo-tutwuri.png')); ?>">
                <?php endif; ?>
            </td>
            <td class="identitas">
                <h4>PEMERINTAH KOTA PADANG</h4>
                <h4>DINAS PENDIDIKAN</h4>
                <h2>SMAN 3 PADANG</h2>
                <h3>PERPUSTAKAAN SEKOLAH</h3>
                <p>Jl. Gajah Mada, Gunung Pangilun, Kota Padang</p>
            </td>
            <td class="logo-kanan">
                <?php if(file_exists(public_path('img/logo-sman3.png'))): ?>
                    <img src="<?php echo e(public_path('img/logo-sman3.png')); ?>">
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>


<!-- JUDUL LAPORAN -->
<div class="title">
    <h1>LAPORAN MONITORING AKTIVITAS PERPUSTAKAAN</h1>
    <p>Periode Akuntansi: <span class="badge-periode"><?php echo e(strtoupper($monthName ?? \Carbon\Carbon::create($year, $month, 1)->translatedFormat('F'))); ?> <?php echo e($year); ?></span></p>
</div>


<!-- LOGIKA EKSTRAKSI DATA -->
<?php
    $lostBooksList = [];
    $damagedBooksList = [];
    foreach($borrowings as $item) {
        $trxStatus = strtolower($item->status ?? '');
        
        if($item->is_collective && $item->borrowedExemplars) {
            foreach($item->borrowedExemplars as $borrowed) {
                $pivotStatus = strtolower($borrowed->status ?? '');
                $masterStatus = isset($borrowed->exemplar) ? strtolower($borrowed->exemplar->status ?? '') : '';
                
                $detail = $item->details->where('id', $borrowed->borrowing_detail_id)->first();
                if(!$detail) $detail = $item->details->first();

                // Ekstrak Hilang
                if(in_array($pivotStatus, ['lost', 'hilang']) || in_array($trxStatus, ['lost', 'hilang']) || in_array($masterStatus, ['lost', 'hilang'])) {
                    if($borrowed->exemplar) {
                        $lostBooksList[] = [
                            'name' => $item->user->name ?? 'Unknown',
                            'role' => $item->user->role ?? '-',
                            'title' => $detail->book->title ?? 'Judul Tidak Ditemukan',
                            'code' => $borrowed->exemplar->code ?? '-',
                            'date' => $item->borrow_date,
                            'trx_status' => $trxStatus
                        ];
                    }
                }

                // Ekstrak Rusak
                if(in_array($pivotStatus, ['damaged', 'rusak']) || in_array($masterStatus, ['damaged', 'rusak'])) {
                    if($borrowed->exemplar) {
                        $damagedBooksList[] = [
                            'name' => $item->user->name ?? 'Unknown',
                            'role' => $item->user->role ?? '-',
                            'title' => $detail->book->title ?? 'Judul Tidak Ditemukan',
                            'code' => $borrowed->exemplar->code ?? '-',
                            'date' => $item->borrow_date,
                            'trx_status' => $trxStatus
                        ];
                    }
                }
            }
        } else {
            foreach($item->details as $detail) {
                $masterStatus = isset($detail->exemplar) ? strtolower($detail->exemplar->status ?? '') : '';
                
                // Ekstrak Hilang
                if(in_array($trxStatus, ['lost', 'hilang']) || in_array($masterStatus, ['lost', 'hilang'])) {
                    if($detail->exemplar) {
                        $lostBooksList[] = [
                            'name' => $item->user->name ?? 'Unknown',
                            'role' => $item->user->role ?? '-',
                            'title' => $detail->book->title ?? 'Judul Tidak Ditemukan',
                            'code' => $detail->exemplar->code ?? '-',
                            'date' => $item->borrow_date,
                            'trx_status' => $trxStatus
                        ];
                    }
                }

                // Ekstrak Rusak
                if(in_array($masterStatus, ['damaged', 'rusak']) || in_array($trxStatus, ['damaged', 'rusak'])) {
                    if($detail->exemplar) {
                        $damagedBooksList[] = [
                            'name' => $item->user->name ?? 'Unknown',
                            'role' => $item->user->role ?? '-',
                            'title' => $detail->book->title ?? 'Judul Tidak Ditemukan',
                            'code' => $detail->exemplar->code ?? '-',
                            'date' => $item->borrow_date,
                            'trx_status' => $trxStatus
                        ];
                    }
                }
            }
        }
    }
    $lostBooksList = collect($lostBooksList)->unique('code')->values()->all();
    $damagedBooksList = collect($damagedBooksList)->unique('code')->values()->all();
?>


<!-- I. RINGKASAN EKSEKUTIF -->
<div class="section-title">I. Ringkasan Eksekutif</div>
<p class="note">
    Pada periode pertanggungjawaban <b><?php echo e(\Carbon\Carbon::create($year,$month,1)->translatedFormat('F Y')); ?></b>, sistem otomasi perpustakaan SISPUS SMAN 3 Padang merekam sebanyak <b class="text-primary"><?php echo e($totalBorrowings); ?></b> berkas sirkulasi peminjaman koleksi buku fisik maupun digital. Dari total log sirkulasi tersebut, sebanyak <b class="text-success"><?php echo e($totalReturned); ?></b> berkas transaksi dinyatakan telah selesai dikembalikan dengan aman oleh siswa maupun guru. Saat ini, sistem mencakup total inventarisasi koleksi sebanyak <b><?php echo e($totalBooks); ?></b> judul eksemplar terdaftar dengan basis interaksi dari <b><?php echo e($totalMembers); ?></b> civitas akademika berstatus anggota aktif perpustakaan.
</p>


<!-- II. INDIKATOR KINERJA UTAMA -->
<div class="section-title">II. Indikator Kinerja Utama</div>
<table>
    <tr>
        <th width="75%">Dimensi Indikator Utama</th>
        <th class="text-center">Kuantitas / Nilai</th>
    </tr>
    <tr><td>Total Koleksi Inventaris Buku Terdaftar</td><td class="text-center fw-bold"><?php echo e($totalBooks); ?></td></tr>
    <tr><td>Total Anggota Ekosistem Aktif</td><td class="text-center fw-bold"><?php echo e($totalMembers); ?></td></tr>
    <tr><td>Log Aktivitas Peminjaman Buku Masuk</td><td class="text-center fw-bold text-primary"><?php echo e($totalBorrowings); ?></td></tr>
    <tr><td>Log Penyelesaian Pengembalian Buku</td><td class="text-center fw-bold text-success"><?php echo e($totalReturned); ?></td></tr>
    <tr><td>Total Pelanggaran Keterlambatan Sirkulasi</td><td class="text-center fw-bold text-danger"><?php echo e($totalLate); ?></td></tr>
    <tr><td>Total Pelanggaran Kasus Eksemplar Hilang</td><td class="text-center fw-bold text-danger"><?php echo e(count($lostBooksList)); ?></td></tr>
    <tr><td>Total Pelanggaran Kasus Eksemplar Rusak</td><td class="text-center fw-bold text-warning"><?php echo e(count($damagedBooksList)); ?></td></tr>
    <tr>
        <td>Rasio Deviasi / Persentase Keterlambatan Pengembalian</td>
        <td class="text-center">
            <?php $rasio = $totalBorrowings > 0 ? round(($totalLate / $totalBorrowings) * 100, 2) : 0; ?>
            <span class="badge <?php echo e($rasio > 20 ? 'badge-danger' : 'badge-success'); ?> fw-bold"><?php echo e($rasio); ?> %</span>
        </td>
    </tr>
</table>


<!-- III & IV & V: TABEL GRID LAYOUT UNTUK PDF -->
<table style="border: none; margin-bottom: 0;">
    <tr>
        <td style="border: none; padding: 0; padding-right: 5px; width: 50%; vertical-align: top;">
            <div class="section-title" style="margin-top: 5px;">III. Buku Terpopuler</div>
            <table>
                <tr>
                    <th class="text-center" width="10%">No</th>
                    <th>Judul Koleksi Buku</th>
                    <th class="text-center" width="25%">Frekuensi</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $popularBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($book->title); ?></td>
                    <td class="text-center"><span class="badge badge-primary"><?php echo e($book->borrowings_count); ?> Kali</span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3" class="text-center">Tidak ada data.</td></tr>
                <?php endif; ?>
            </table>
        </td>
        <td style="border: none; padding: 0; padding-left: 5px; width: 50%; vertical-align: top;">
            <div class="section-title" style="margin-top: 5px;">IV. Jenis Peminjaman</div>
            <table>
                <tr>
                    <th>Kategori Jenis</th>
                    <th class="text-center">Kuantitas</th>
                </tr>
                <?php $__currentLoopData = $popularCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(ucfirst($item->loan_type)); ?></td>
                    <td class="text-center fw-bold"><?php echo e($item->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            <div class="section-title" style="margin-top: 15px;">V. Segmentasi Alur Sirkulasi</div>
            <table>
                <tr>
                    <th>Indikator Alur</th>
                    <th class="text-center">Jumlah</th>
                </tr>
                <tr>
                    <td>Sirkulasi Kolektif</td>
                    <td class="text-center fw-bold text-primary"><?php echo e($borrowings->where('is_collective', true)->count()); ?></td>
                </tr>
                <tr>
                    <td>Sirkulasi Individu</td>
                    <td class="text-center fw-bold text-success"><?php echo e($borrowings->where('is_collective', false)->count()); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- VI. AUDIT KERUGIAN ASET (BUKU HILANG) -->
<div class="section-title">VI. Audit Kerugian Aset (Buku Hilang)</div>
<?php if(count($lostBooksList) > 0): ?>
    <div style="background-color: #fee2e2; border: 1px solid #fecaca; color: #991b1b; padding: 10px; font-size: 10px; margin-bottom: 10px; border-radius: 4px;">
        <b>Peringatan Aset:</b> Terdapat <b><?php echo e(count($lostBooksList)); ?> eksemplar</b> buku yang dilaporkan hilang pada periode laporan ini.
    </div>
<?php endif; ?>
<table>
    <tr>
        <th width="5%" class="text-center">No</th>
        <th width="20%">Nama Peminjam</th>
        <th width="35%">Judul Koleksi</th>
        <th width="15%" class="text-center">Eksemplar</th>
        <th width="12%" class="text-center">Dipinjam</th>
        <th width="13%" class="text-center">Status</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $lostBooksList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td class="text-center"><?php echo e($loop->iteration); ?></td>
        <td>
            <b><?php echo e($lost['name']); ?></b><br>
            <i style="font-size: 9px; color:#555;"><?php echo e(ucfirst($lost['role'])); ?></i>
        </td>
        <td><?php echo e($lost['title']); ?></td>
        <td class="text-center"><span class="badge badge-danger"><?php echo e($lost['code']); ?></span></td>
        <td class="text-center"><?php echo e(\Carbon\Carbon::parse($lost['date'])->format('d/m/y')); ?></td>
        <td class="text-center">
            <?php if(in_array(strtolower($lost['trx_status']), ['dikembalikan', 'selesai'])): ?>
                <span class="text-success fw-bold">Diganti</span>
            <?php else: ?>
                <span class="text-danger fw-bold">Hilang</span>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6" class="text-center">Aman. Tidak ada kerugian buku pada periode ini.</td>
    </tr>
    <?php endif; ?>
</table>


<!-- VII. AUDIT KERUSAKAN ASET (BUKU RUSAK) -->
<div class="section-title">VII. Audit Kerusakan Aset (Buku Rusak)</div>
<?php if(count($damagedBooksList) > 0): ?>
    <div style="background-color: #fef3c7; border: 1px solid #fde68a; color: #92400e; padding: 10px; font-size: 10px; margin-bottom: 10px; border-radius: 4px;">
        <b>Peringatan Aset:</b> Terdapat <b><?php echo e(count($damagedBooksList)); ?> eksemplar</b> buku yang dilaporkan rusak pada periode laporan ini.
    </div>
<?php endif; ?>
<table>
    <tr>
        <th width="5%" class="text-center">No</th>
        <th width="20%">Nama Peminjam</th>
        <th width="35%">Judul Koleksi</th>
        <th width="15%" class="text-center">Eksemplar</th>
        <th width="12%" class="text-center">Dipinjam</th>
        <th width="13%" class="text-center">Status</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $damagedBooksList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $damaged): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td class="text-center"><?php echo e($loop->iteration); ?></td>
        <td>
            <b><?php echo e($damaged['name']); ?></b><br>
            <i style="font-size: 9px; color:#555;"><?php echo e(ucfirst($damaged['role'])); ?></i>
        </td>
        <td><?php echo e($damaged['title']); ?></td>
        <td class="text-center"><span class="badge badge-warning"><?php echo e($damaged['code']); ?></span></td>
        <td class="text-center"><?php echo e(\Carbon\Carbon::parse($damaged['date'])->format('d/m/y')); ?></td>
        <td class="text-center">
            <?php if(in_array(strtolower($damaged['trx_status']), ['dikembalikan', 'selesai'])): ?>
                <span class="text-success fw-bold">Selesai</span>
            <?php else: ?>
                <span class="text-warning fw-bold">Rusak</span>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6" class="text-center">Aman. Tidak ada kerusakan fisik buku pada periode ini.</td>
    </tr>
    <?php endif; ?>
</table>


<!-- VIII. SAMPEL RIWAYAT LOG TRANSAKSI -->
<div class="section-title" style="page-break-before: always;">VIII. Sampel Riwayat Log Transaksi Mutakhir</div>
<table>
    <tr>
        <th class="text-center" width="4%">No</th>
        <th width="14%">Nama / Role</th>
        <th width="25%">Katalog Buku</th>
        <th width="12%">Eksemplar</th>
        <th class="text-center" width="9%">Jenis</th>
        <th class="text-center" width="10%">Status</th>
        <th class="text-center" width="12%">Keterangan</th>
        <th width="14%">Waktu (P/K)</th>
    </tr>
    <?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($loop->iteration); ?></td>
        <td>
            <b><?php echo e($item->user->name ?? '-'); ?></b><br>
            <span class="badge <?php echo e(($item->user->role ?? '') == 'guru' ? 'badge-warning' : 'badge-primary'); ?>"><?php echo e(ucfirst($item->user->role ?? '-')); ?></span>
        </td>
        <td>
            <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-bottom:4px;">&#8226; <?php echo e($detail->book->title); ?> (<?php echo e($detail->qty); ?>x)</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
            <?php if($item->is_collective): ?>
                <?php $__currentLoopData = $item->borrowedExemplars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $bStatus = strtolower($borrowed->status ?? '');
                        $mStatus = strtolower(optional($borrowed->exemplar)->status ?? '');
                        $badgeStyle = '';
                        if($bStatus == 'lost' || $mStatus == 'lost' || $mStatus == 'hilang') $badgeStyle = 'badge-danger';
                        elseif($bStatus == 'damaged' || $mStatus == 'damaged' || $mStatus == 'rusak') $badgeStyle = 'badge-warning';
                    ?>
                    <span class="badge <?php echo e($badgeStyle); ?>" style="margin-bottom:2px;"><?php echo e($borrowed->exemplar->code); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($detail->exemplar): ?>
                        <?php
                            $mStatus = strtolower($detail->exemplar->status ?? '');
                            $badgeStyle = '';
                            if($mStatus == 'lost' || $mStatus == 'hilang') $badgeStyle = 'badge-danger';
                            elseif($mStatus == 'damaged' || $mStatus == 'rusak') $badgeStyle = 'badge-warning';
                        ?>
                        <span class="badge <?php echo e($badgeStyle); ?>" style="margin-bottom:2px;"><?php echo e($detail->exemplar->code); ?></span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </td>
        <td class="text-center"><?php echo e($item->is_collective ? 'Kolektif' : 'Individu'); ?></td>
        <td class="text-center">
            <?php
                $sts = strtolower($item->status);
                $badgeCls = '';
                if($sts == 'dikembalikan') $badgeCls = 'badge-success';
                elseif($sts == 'dipinjam') $badgeCls = 'badge-warning';
                elseif($sts == 'menunggu_pengembalian') $badgeCls = 'badge-primary';
                elseif($sts == 'hilang') $badgeCls = 'badge-danger';
                elseif($sts == 'rusak') $badgeCls = 'badge-warning';
            ?>
            <span class="badge <?php echo e($badgeCls); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $item->status))); ?></span>
        </td>
        <td class="text-center">
            <?php $retDate = \Carbon\Carbon::parse($item->return_date)->startOfDay(); ?>
            <?php if($sts == 'dikembalikan'): ?>
                <?php if($item->returned_at && \Carbon\Carbon::parse($item->returned_at)->startOfDay()->gt($retDate)): ?>
                    <span class="text-danger fw-bold">Terlambat</span>
                <?php else: ?>
                    <span class="text-success fw-bold">Tepat Waktu</span>
                <?php endif; ?>
            <?php elseif(in_array($sts, ['dipinjam', 'menunggu_pengembalian'])): ?>
                <?php if(\Carbon\Carbon::now()->startOfDay()->gt($retDate)): ?>
                    <span class="text-danger fw-bold">Terlambat</span>
                <?php else: ?>
                    <span class="text-primary fw-bold">Berjalan</span>
                <?php endif; ?>
            <?php else: ?>
                -
            <?php endif; ?>
        </td>
        <td style="font-size: 9px; color: #555;">
            <?php echo e(\Carbon\Carbon::parse($item->borrow_date)->format('d/m/y')); ?><br>
            s/d<br>
            <?php echo e(\Carbon\Carbon::parse($item->return_date)->format('d/m/y')); ?>

        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<!-- IX & X: TABEL GRID -->
<table style="border: none; margin-bottom: 0;">
    <tr>
        <td style="border: none; padding: 0; padding-right: 5px; width: 50%; vertical-align: top;">
            <div class="section-title" style="margin-top: 5px;">IX. Top 5 Anggota Teraktif</div>
            <table>
                <tr>
                    <th class="text-center" width="10%">Rank</th>
                    <th>Nama Anggota</th>
                    <th>Role</th>
                    <th class="text-center" width="20%">Skor</th>
                </tr>
                <?php $__currentLoopData = $users->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center fw-bold"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e(ucfirst($user->role)); ?></td>
                    <td class="text-center fw-bold text-primary"><?php echo e($user->points); ?> pts</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </td>
        <td style="border: none; padding: 0; padding-left: 5px; width: 50%; vertical-align: top;">
            <div class="section-title" style="margin-top: 5px;">X. Catatan & Rekomendasi</div>
            <div style="background-color: #f9fafb; border: 1px solid #e5e7eb; padding: 10px; font-size: 10px; color: #4b5563;">
                <ul style="margin: 0; padding-left: 15px;">
                    <li style="margin-bottom: 4px;">Total sirkulasi mencakup <b><?php echo e($totalBorrowings); ?></b> entitas berkas.</li>
                    <li style="margin-bottom: 4px;">Rasio kesuksesan pemulihan buku: <b><?php echo e($totalBorrowings > 0 ? round(($totalReturned / $totalBorrowings) * 100, 2) : 0); ?>%</b>.</li>
                    <li style="margin-bottom: 4px;">Pelanggaran keterlambatan terverifikasi sebanyak <b><?php echo e($totalLate); ?></b> kasus aktif.</li>
                    <li style="margin-bottom: 4px;">Kasus kerusakan eksemplar tercatat sebanyak <b><?php echo e(count($damagedBooksList)); ?></b> unit.</li>
                    <li>Sirkulasi kolektif tercatat sebanyak <b><?php echo e($borrowings->where('is_collective', true)->count()); ?></b> transaksi.</li>
                </ul>
            </div>
        </td>
    </tr>
</table>


<!-- TANDA TANGAN -->
<div class="footer">
    <table class="signature-table">
        <tr>
            <td>
                <!-- Jarak kosong untuk sisi kiri -->
            </td>
            <td>
                Padang, <?php echo e(now()->translatedFormat('d F Y')); ?><br>
                Kepala Urusan Perpustakaan Sekolah
                <br><br><br><br><br>
                <span class="signature-name"><?php echo e($kepalaPustakawan->name ?? 'Drs. Afrizal, M.Pd'); ?></span><br>
                NIP. <?php echo e($kepalaPustakawan->nis_nip ?? '_________________'); ?>

            </td>
        </tr>
    </table>
</div>

</body>
</html><?php /**PATH /home/sisd2648/perpustakaan/resources/views/kepala/laporan-pdf.blade.php ENDPATH**/ ?>