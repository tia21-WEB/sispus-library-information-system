<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Laporan Perpustakaan</title>
<style>
body{
    font-family: DejaVu Sans, sans-serif;
    font-size:11px;
    margin:20px;
    color:#222;
    line-height:1.4;
}

/* HEADER */
.header-table{
    width:100%;
    border:none;
    margin-bottom:5px;
}
.header-table td{
    border:none;
    vertical-align:middle;
}
.logo{
    width:75px;
}
.text-center{
    text-align:center;
}
.line{
    border-top:2px solid #000;
    margin-top:4px;
    margin-bottom:12px;
}

/* SECTION */
.section-title{
    font-size:12px;
    font-weight:bold;
    background:#efefef;
    padding:5px 8px;
    margin-top:16px;
    margin-bottom:8px;
    border-left:4px solid #000;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
    margin-top:6px;
}
th,
td{
    border:1px solid #000;
    padding:4px;
    font-size:9px;
    vertical-align:top;
    word-wrap:break-word;
}
th{
    background:#efefef;
    font-weight:bold;
    text-align:center;
}

/* Ringkasan */
.summary-table td:first-child{
    width:60%;
    font-weight:bold;
}

/* Paragraf */
.note{
    text-align:justify;
    font-size:10px;
    line-height:1.5;
}

/* Signature */
.signature{
    margin-top:35px;
    width:100%;
}
.signature td{
    border:none;
    text-align:center;
    vertical-align:top;
}
.small{
    font-size:9px;
}
</style>
</head>

<body>


<table class="header-table">
<tr>
<td width="15%" class="text-center">
<?php if(file_exists(public_path('img/logo-tutwuri.png'))): ?> 
    <img src="<?php echo e(public_path('img/logo-tutwuri.png')); ?>" class="logo">
<?php endif; ?>
</td>
<td width="70%" class="text-center">
<div style="font-size:14px;font-weight:bold;">PEMERINTAH KOTA PADANG</div>
<div style="font-size:13px;font-weight:bold;">DINAS PENDIDIKAN</div>
<div style="font-size:18px;font-weight:bold;">SMA NEGERI 3 PADANG</div>
<div style="font-size:13px;font-weight:bold;">PERPUSTAKAAN SMA NEGERI 3 PADANG</div>
<div class="small">Jl. Gajah Mada, Gunung Pangilun, Kota Padang</div>
</td>
<td width="15%" class="text-center">
<?php if(file_exists(public_path('img/logo-sman3.png'))): ?> 
    <img src="<?php echo e(public_path('img/logo-sman3.png')); ?>" class="logo">
<?php endif; ?>
</td>
</tr>
</table>

<div class="line"></div>


<div class="text-center">
<h3>LAPORAN TRANSAKSI PERPUSTAKAAN</h3>
<b>PERIODE <?php echo e(strtoupper($monthName)); ?> <?php echo e($year); ?></b>
<br><br>
Tanggal Cetak : <?php echo e(date('d-m-Y')); ?>

</div>


<div class="section-title">A. Ringkasan Data</div>
<table>
<tr>
<td>Total Buku</td>
<td><?php echo e($totalBooks); ?></td>
</tr>
<tr>
<td>Total Anggota</td>
<td><?php echo e($totalMembers); ?></td>
</tr>
<tr>
<td>Total Peminjaman</td>
<td><?php echo e($totalBorrowings); ?></td>
</tr>
<tr>
<td>Total Pengembalian</td>
<td><?php echo e($totalReturned); ?></td>
</tr>
</table>


<div class="section-title">B. Buku Terpopuler</div>
<table>
<thead>
<tr>
<th>No</th>
<th>Judul Buku</th>
<th>Total Peminjaman</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $popularBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($loop->iteration); ?></td>
<td><?php echo e($book->title); ?></td>
<td><?php echo e($book->borrowings_count); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>


<div class="section-title">C. Kategori Peminjaman Terfavorit</div>
<table>
<thead>
<tr>
<th>No</th>
<th>Kategori</th>
<th>Total</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $popularCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($loop->iteration); ?></td>
<td><?php echo e(ucfirst($category->loan_type)); ?></td>
<td><?php echo e($category->total); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>


<div class="section-title">D. Statistik Peminjaman Kolektif</div>
<?php
$totalTransaksiKolektif = 0;
$totalExemplarKolektif = 0;
foreach($borrowings as $b){
    if($b->is_collective){
        $totalTransaksiKolektif++;
        $totalExemplarKolektif += $b->borrowedExemplars->count();
    }
}
?>
<table>
<tr>
<td width="70%">Total Transaksi Kolektif</td>
<td><?php echo e($totalTransaksiKolektif); ?></td>
</tr>
<tr>
<td>Total Exemplar Kolektif</td>
<td><?php echo e($totalExemplarKolektif); ?></td>
</tr>
</table>


<div class="section-title">E. Statistik Buku Hilang</div>
<?php
$totalHilang = 0;
foreach($borrowings as $b){
    $totalHilang += $b->borrowedExemplars->where('status','lost')->count();
}
?>
<table>
<tr>
<td width="70%">Total Exemplar Hilang</td>
<td><?php echo e($totalHilang); ?></td>
</tr>
</table>

<table>
<thead>
<tr>
<th width="10%">No</th>
<th>Kode Exemplar Hilang</th>
</tr>
</thead>
<tbody>
<?php $noHilang = 1; ?>
<?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $item->borrowedExemplars->where('status','lost'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($noHilang++); ?></td>
            <td><?php echo e($lost->exemplar->code); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($noHilang == 1): ?>
<tr>
<td colspan="2" align="center">Tidak ada buku hilang</td>
</tr>
<?php endif; ?>
</tbody>
</table>


<div class="section-title">F. Statistik Buku Rusak</div>
<?php
$totalRusak = 0;
foreach($borrowings as $b){
    $totalRusak += $b->borrowedExemplars->where('status','damaged')->count();
}
?>
<table>
<tr>
<td width="70%">Total Exemplar Rusak</td>
<td><?php echo e($totalRusak); ?></td>
</tr>
</table>

<table>
<thead>
<tr>
<th width="10%">No</th>
<th>Kode Exemplar Rusak</th>
</tr>
</thead>
<tbody>
<?php $noRusak = 1; ?>
<?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $item->borrowedExemplars->where('status','damaged'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $damaged): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($noRusak++); ?></td>
            <td><?php echo e($damaged->exemplar->code); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($noRusak == 1): ?>
<tr>
<td colspan="2" align="center">Tidak ada buku rusak</td>
</tr>
<?php endif; ?>
</tbody>
</table>


<div class="section-title">G. Detail Transaksi Lengkap</div>
<table>
<thead>
<tr>
<th width="3%">No</th>
<th width="10%">Nama</th>
<th width="6%">Role</th>
<th width="18%">Buku</th>
<th width="8%">Jenis</th>
<th width="12%">Keterangan</th>
<th width="9%">Status</th>
<th width="10%">Ket</th>
<th width="14%">Periode</th>
</tr>
</thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td><?php echo e($loop->iteration); ?></td>
<td><?php echo e($item->user->name); ?></td>
<td><?php echo e(ucfirst($item->user->role)); ?></td>
<td>
<?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<b><?php echo e($detail->book->title); ?></b>
<br>
<?php if($item->is_collective): ?>
<?php echo e($detail->qty); ?> Eksemplar
<br>
<?php $__currentLoopData = $item->borrowedExemplars->where('borrowing_detail_id',$detail->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($borrowed->status == 'lost'): ?>
        <span style="color:red"><?php echo e($borrowed->exemplar->code); ?></span>
    <?php elseif($borrowed->status == 'damaged'): ?>
        <span style="color:orange; font-weight:bold;"><?php echo e($borrowed->exemplar->code); ?></span>
    <?php else: ?>
        <?php echo e($borrowed->exemplar->code); ?>

    <?php endif; ?>
    &nbsp;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<?php if($detail->exemplar): ?>
    <?php if($detail->exemplar->status == 'lost'): ?>
        <span style="color:red"><?php echo e($detail->exemplar->code); ?></span>
    <?php elseif($detail->exemplar->status == 'damaged'): ?>
        <span style="color:orange; font-weight:bold;"><?php echo e($detail->exemplar->code); ?></span>
    <?php else: ?>
        <?php echo e($detail->exemplar->code); ?>

    <?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<br><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>

<td>
<?php if($item->is_collective): ?>
Kolektif
<?php else: ?>
Individu
<?php endif; ?>
</td>

<td>
<?php if($item->is_collective): ?>
Kelas : <?php echo e($item->class_name); ?>

<br>
Total Exemplar : <?php echo e($item->borrowedExemplars->count()); ?>

<br>
Hilang : <?php echo e($item->borrowedExemplars->where('status','lost')->count()); ?>

<br>
Rusak : <?php echo e($item->borrowedExemplars->where('status','damaged')->count()); ?>

<?php else: ?>
-
<?php endif; ?>
</td>

<td><?php echo e(ucfirst($item->status)); ?></td>

<td>
<?php if($item->status == 'dikembalikan'): ?>
    <?php if($item->returned_at && \Carbon\Carbon::parse($item->returned_at)->gt(\Carbon\Carbon::parse($item->return_date))): ?>
        <span style="color:red;font-weight:bold;">Terlambat</span>
    <?php else: ?>
        <span style="color:green;font-weight:bold;">Tepat Waktu</span>
    <?php endif; ?>
<?php elseif($item->status == 'dipinjam'): ?>
    <?php if(\Carbon\Carbon::parse($item->return_date)->isPast()): ?>
        <span style="color:red;font-weight:bold;">Terlambat</span>
    <?php else: ?>
        Sedang Dipinjam
    <?php endif; ?>
<?php else: ?>
    -
<?php endif; ?>
</td>

<td>
<?php echo e(\Carbon\Carbon::parse($item->borrow_date)->format('d-m-Y')); ?>

<br>s/d<br>
<?php echo e(\Carbon\Carbon::parse($item->return_date)->format('d-m-Y')); ?>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
<td colspan="9" align="center">Tidak ada data transaksi</td>
</tr>
<?php endif; ?>
</tbody>
</table>


<table class="signature">
<tr>
<td>
Mengetahui,
<br><br>Kepala Pustakawan<br><br>
<b><?php echo e($kepalaPustakawan->name ?? '-'); ?></b>
<br>NIP : __________
</td>
<td>
Pustakawan
<br><br><br><br>
<b><?php echo e($pustakawan->name ?? '........................'); ?></b>
</td>
</tr>
</table>

</body>
</html><?php /**PATH /home/sisd2648/perpustakaan/resources/views/laporan-pdf.blade.php ENDPATH**/ ?>