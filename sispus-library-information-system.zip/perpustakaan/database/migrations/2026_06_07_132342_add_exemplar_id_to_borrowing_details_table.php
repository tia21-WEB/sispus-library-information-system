<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('borrowing_details', function (Blueprint $table) {

            $table->foreignId('exemplar_id')
                ->nullable()
                ->after('book_id')
                ->constrained('exemplars')
                ->nullOnDelete();

        });
    }

    public function down(): void
    {
        Schema::table('borrowing_details', function (Blueprint $table) {

            $table->dropForeign(['exemplar_id']);

            $table->dropColumn('exemplar_id');

        });
    }
};