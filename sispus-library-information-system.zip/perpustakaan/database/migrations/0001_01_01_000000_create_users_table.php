<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('nis_nip')->unique(); // Sesuai kesepakatan login kita sebelumnya
            $table->string('email')->unique();
            $table->string('password');
            $table->enum('role', ['siswa', 'guru', 'pustakawan', 'kepala_pustakawan']); // Sesuai Class Diagram proposal Anda
            $table->integer('points')->default(0); // Wadah Gamifikasi Poin
            $table->string('badge')->default('Bronze'); // Wadah Gamifikasi Lencana/Badge
            $table->string('phone')->nullable();
            $table->text('address')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};