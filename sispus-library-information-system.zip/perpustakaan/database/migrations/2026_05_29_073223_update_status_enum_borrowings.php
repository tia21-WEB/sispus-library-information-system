<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            ALTER TABLE borrowings
            MODIFY status ENUM(
                'menunggu',
                'dipinjam',
                'menunggu_pengembalian',
                'dikembalikan',
                'ditolak'
            ) DEFAULT 'menunggu'
        ");
    }

    public function down(): void
    {
        DB::statement("
            ALTER TABLE borrowings
            MODIFY status ENUM(
                'menunggu',
                'dipinjam',
                'dikembalikan',
                'ditolak'
            ) DEFAULT 'menunggu'
        ");
    }
};