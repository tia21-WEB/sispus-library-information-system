<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            ALTER TABLE exemplars
            MODIFY status ENUM(
                'available',
                'borrowed',
                'lost',
                'damaged'
            )
            DEFAULT 'available'
        ");
    }

    public function down(): void
    {
        DB::statement("
            ALTER TABLE exemplars
            MODIFY status ENUM(
                'available',
                'borrowed'
            )
            DEFAULT 'available'
        ");
    }
};