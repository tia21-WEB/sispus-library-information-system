<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table(
            'borrowings',
            function (Blueprint $table) {

                $table->integer('quantity')
                    ->default(1)
                    ->after('class_name');

            }
        );
    }

    public function down(): void
    {
        Schema::table(
            'borrowings',
            function (Blueprint $table) {

                $table->dropColumn(
                    'quantity'
                );

            }
        );
    }
};