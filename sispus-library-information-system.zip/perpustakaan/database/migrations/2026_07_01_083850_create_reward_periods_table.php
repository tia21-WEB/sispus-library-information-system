<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reward_periods', function (Blueprint $table) {

            $table->id();

            $table->string('name');

            $table->enum('semester', ['ganjil', 'genap']);

            $table->string('academic_year');

            $table->date('start_date');

            $table->date('end_date');

            $table->boolean('is_active')->default(false);

            $table->timestamps();

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reward_periods');
    }
};