<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('book_approvals', function (Blueprint $table) {

            $table->id();

            $table->foreignId('requested_by')
                  ->constrained('users')
                  ->onDelete('cascade');

            $table->enum('action', [
                'create',
                'update',
                'delete'
            ]);

            $table->json('book_data');

            $table->enum('status', [
                'pending',
                'approved',
                'rejected'
            ])->default('pending');

            $table->foreignId('approved_by')
                  ->nullable()
                  ->constrained('users')
                  ->nullOnDelete();

            $table->timestamp('approved_at')
                  ->nullable();

            $table->text('rejection_reason')
                  ->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('book_approvals');
    }
};