<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('borrowing_exemplars', function (Blueprint $table) {

            $table->id();

            $table->foreignId('borrowing_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('borrowing_detail_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('exemplar_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->enum('status', [
                'borrowed',
                'returned',
                'lost'
            ])->default('borrowed');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('borrowing_exemplars');
    }
};