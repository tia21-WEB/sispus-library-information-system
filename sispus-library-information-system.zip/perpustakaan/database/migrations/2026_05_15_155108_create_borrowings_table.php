<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('borrowings', function (Blueprint $table) {

            $table->id();

            // siswa peminjam
            $table->foreignId('user_id')
                  ->constrained()
                  ->onDelete('cascade');

            // buku dipinjam
            $table->foreignId('book_id')
                  ->constrained()
                  ->onDelete('cascade');

            // tanggal pinjam
            $table->date('borrow_date');

            // batas pengembalian
            $table->date('return_date');

            // status transaksi
            $table->enum('status', [

                'menunggu',
                'dipinjam',
                'dikembalikan',
                'ditolak'

            ])->default('menunggu');

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('borrowings');
    }
};