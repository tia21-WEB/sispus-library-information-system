<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('borrowings', function (Blueprint $table) {

            $table->boolean(
                'is_collective'
            )->default(false);

            $table->string(
                'class_name'
            )->nullable();

        });
    }

    public function down(): void
    {
        Schema::table('borrowings', function (Blueprint $table) {

            $table->dropColumn([
                'is_collective',
                'class_name'
            ]);

        });
    }
};