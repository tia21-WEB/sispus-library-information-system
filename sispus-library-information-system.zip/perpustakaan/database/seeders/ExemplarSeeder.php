<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;
use App\Models\Exemplar;

class ExemplarSeeder extends Seeder
{
    public function run(): void
    {
        foreach (Book::all() as $book) {

            for ($i = 1; $i <= $book->stock; $i++) {

                Exemplar::create([

                    'book_id' => $book->id,

                    'code' => strtoupper(
                        substr(
                            preg_replace('/[^A-Za-z]/', '', $book->title),
                            0,
                            3
                        )
                    ) . '-' . str_pad($i, 3, '0', STR_PAD_LEFT),

                    'status' => 'available'

                ]);
            }
        }
    }
}