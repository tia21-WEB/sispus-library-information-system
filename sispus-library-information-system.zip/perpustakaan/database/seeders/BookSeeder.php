<?php

namespace database\seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Book;
use App\Models\Exemplar;

class BookSeeder extends Seeder
{
    public function run(): void
    {
        // --- KATEGORI 1: NOVEL ---
        $novel = Category::create(['name' => 'Novel & Sastra']);

        $book1 = Book::create([
            'category_id' => $novel->id,
            'title' => 'Laskar Pelangi',
            'author' => 'Andrea Hirata',
            'publisher' => 'Bentang Pustaka',
            'publication_year' => 2005,
            'description' => 'Kisah perjuangan 10 anak Belitung berburu mimpi.',
            'cover' => 'laskar_pelangi.jpg'
        ]);

        // Buat 2 eksemplar fisik untuk buku Laskar Pelangi
        Exemplar::create(['book_id' => $book1->id, 'code' => 'LP-001', 'status' => 'available']);
        Exemplar::create(['book_id' => $book1->id, 'code' => 'LP-002', 'status' => 'available']);


        // --- KATEGORI 2: TEKNOLOGI ---
        $tech = Category::create(['name' => 'Teknologi & Komputer']);

        $book2 = Book::create([
            'category_id' => $tech->id,
            'title' => 'Belajar Menguasai Laravel 11',
            'author' => 'Eko Kurniawan',
            'publisher' => 'TechMedia',
            'publication_year' => 2024,
            'description' => 'Panduan lengkap membuat aplikasi web dan API modern.',
            'cover' => 'laravel11.jpg'
        ]);

        // Buat 2 eksemplar fisik untuk buku Laravel
        Exemplar::create(['book_id' => $book2->id, 'code' => 'LV-001', 'status' => 'available']);
        Exemplar::create(['book_id' => $book2->id, 'code' => 'LV-002', 'status' => 'available']);
    }
}