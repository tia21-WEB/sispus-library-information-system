<?php

namespace database\seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Akun Pustakawan (NIP:19850101 )
        User::create([
            'name' => 'Dewi Pustakawan',
            'email' => 'pustakawan@gmail.com', // Tetap diisi formalitas DB
            'password' => Hash::make('password123'),
            'role' => 'pustakawan',
            'nis_nip' => '19850101', // DIPAKAI LOGIN DESKTOP
            'phone' => '081211112222',
            'address' => 'Ruang Kerja Perpustakaan',
        ]);

        // 2. Akun Kepala Perpustakaan (NIP: 19700512)
        User::create([
            'name' => 'Drs. Subagyo',
            'email' => 'kepala@gmail.com',
            'password' => Hash::make('password123'),
            'role' => 'kepala_perpustakaan',
            'nis_nip' => '19700512', // DIPAKAI LOGIN DESKTOP
            'phone' => '081233334444',
            'address' => 'Kantor Kepala Sekolah',
        ]);

        // 3. Akun Siswa (NIS: 20260001)
        User::create([
            'name' => 'Rian Hidayat',
            'email' => 'rian@gmail.com',
            'password' => Hash::make('password123'),
            'role' => 'siswa',
            'nis_nip' => '20260001', // DIPAKAI LOGIN MOBILE & QR CODE
            'phone' => '085799998888',
            'address' => 'Kelas XI MIPA 2',
        ]);
    }
}